wget -c https://old.kali.org/kali/pool/main/l/linux/linux-headers-6.6.15-common_6.6.15-2kali1_all.deb
dpkg -i linux-headers-6.6.15-common_6.6.15-2kali1_all.deb
wget -c https://old.kali.org/kali/pool/main/l/linux/linux-kbuild-6.6.15_6.6.15-2kali1%2Bb1_amd64.deb
dpkg -i linux-kbuild-6.6.15_6.6.15-2kali1+b1_amd64.deb
wget -c https://old.kali.org/kali/pool/main/l/linux/linux-headers-6.6.15-amd64_6.6.15-2kali1%2Bb1_amd64.deb
dpkg -i linux-headers-6.6.15-amd64_6.6.15-2kali1+b1_amd64.deb