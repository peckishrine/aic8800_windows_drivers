wget -c https://old.kali.org/kali/pool/main/l/linux/linux-headers-6.1.0-kali9-common_6.1.27-1kali1_all.deb
dpkg -i linux-headers-6.1.0-kali9-common_6.1.27-1kali1_all.deb
wget -c http://old.kali.org/kali/pool/main/l/linux/linux-kbuild-6.1_6.1.27-1kali1_amd64.deb
dpkg -i linux-kbuild-6.1_6.1.27-1kali1_amd64.deb
wget -c http://old.kali.org/kali/pool/main/l/linux/linux-compiler-gcc-12-x86_6.1.27-1kali1_amd64.deb
dpkg -i linux-compiler-gcc-12-x86_6.1.27-1kali1_amd64.deb
wget -c http://old.kali.org/kali/pool/main/l/linux/linux-headers-6.1.0-kali9-amd64_6.1.27-1kali1_amd64.deb
dpkg -i linux-headers-6.1.0-kali9-amd64_6.1.27-1kali1_amd64.deb
